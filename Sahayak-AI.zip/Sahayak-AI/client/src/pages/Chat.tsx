import { useState, useRef, useEffect } from "react";
import { Send, Mic, Globe, Info, Menu, User, Volume2, ShieldCheck, ChevronRight } from "lucide-react";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Avatar, AvatarFallback, AvatarImage } from "@/components/ui/avatar";
import { ScrollArea } from "@/components/ui/scroll-area";
import {
  DropdownMenu,
  DropdownMenuContent,
  DropdownMenuItem,
  DropdownMenuTrigger,
} from "@/components/ui/dropdown-menu";
import { motion, AnimatePresence } from "framer-motion";

// Using the generated avatar
import sahayakAvatar from "@/assets/images/sahayak-avatar.png";

type Message = {
  id: string;
  role: "system" | "user" | "assistant";
  content: string;
  timestamp: Date;
  chips?: string[];
  schemeCard?: {
    title: string;
    description: string;
    eligibility: string;
  };
};

export default function Chat() {
  const [messages, setMessages] = useState<Message[]>([
    {
      id: "1",
      role: "assistant",
      content: "Namaste! I am SAHAYAK AI, your digital public servant. How can I help you today? I can assist you with government schemes, education, healthcare, and employment resources.",
      timestamp: new Date(),
      chips: [
        "Farmer Schemes",
        "Healthcare Benefits",
        "Education Scholarships",
        "Housing Assistance"
      ]
    }
  ]);
  const [inputValue, setInputValue] = useState("");
  const [isTyping, setIsTyping] = useState(false);
  const [language, setLanguage] = useState("English");
  const scrollRef = useRef<HTMLDivElement>(null);

  // Auto-scroll to bottom
  useEffect(() => {
    if (scrollRef.current) {
      const scrollContainer = scrollRef.current.querySelector('[data-radix-scroll-area-viewport]');
      if (scrollContainer) {
        scrollContainer.scrollTop = scrollContainer.scrollHeight;
      }
    }
  }, [messages, isTyping]);

  const handleSend = () => {
    if (!inputValue.trim()) return;

    const newUserMsg: Message = {
      id: Date.now().toString(),
      role: "user",
      content: inputValue,
      timestamp: new Date(),
    };

    setMessages((prev) => [...prev, newUserMsg]);
    setInputValue("");
    setIsTyping(true);

    // Mock AI response
    setTimeout(() => {
      setIsTyping(false);
      let aiResponse: Message = {
        id: (Date.now() + 1).toString(),
        role: "assistant",
        content: "I understand you're asking about farmer schemes. Based on typical eligibility, the PM-KISAN scheme might be relevant for you. Would you like me to guide you through the details?",
        timestamp: new Date(),
        chips: ["Yes, show details", "What else is available?"]
      };

      if (newUserMsg.content.toLowerCase().includes("farmer")) {
        aiResponse.content = "For farmers, the primary central scheme is PM-KISAN (Pradhan Mantri Kisan Samman Nidhi), which provides financial support to landholding farmers.";
        aiResponse.schemeCard = {
          title: "PM-KISAN Samman Nidhi",
          description: "Provides income support of ₹6,000 per year to all landholding farmer families.",
          eligibility: "Landholding farmer families with cultivable land in their names."
        };
        aiResponse.chips = ["How to apply?", "Check my eligibility"];
      } else if (newUserMsg.content.toLowerCase().includes("apply") && messages.some(m => m.schemeCard?.title === "PM-KISAN Samman Nidhi")) {
         aiResponse.content = "To apply for PM-KISAN, you need the following:\n1. Aadhaar Card\n2. Bank Account linked to Aadhaar\n3. Land ownership documents\n\nYou can apply through your nearest Common Service Center (CSC) or online on the official portal. Shall I find the nearest CSC for you?";
         aiResponse.chips = ["Find nearest CSC", "Start online application"];
         aiResponse.schemeCard = undefined;
      }

      setMessages((prev) => [...prev, aiResponse]);
    }, 1500);
  };

  const handleChipClick = (chip: string) => {
    setInputValue(chip);
    // Slight delay to simulate user typing/sending the chip
    setTimeout(() => {
      const sendBtn = document.getElementById("send-btn");
      if (sendBtn) sendBtn.click();
    }, 50);
  };

  return (
    <div className="flex flex-col h-screen max-w-md mx-auto bg-card shadow-2xl relative overflow-hidden sm:border-x sm:border-border">
      {/* Header */}
      <header className="flex items-center justify-between px-4 py-3 bg-primary text-primary-foreground shadow-sm z-10">
        <div className="flex items-center gap-3">
          <Avatar className="h-10 w-10 border-2 border-primary-foreground/20 shadow-sm bg-white">
            <AvatarImage src={sahayakAvatar} alt="SAHAYAK" className="p-1 object-contain" />
            <AvatarFallback className="text-primary bg-white font-bold">SA</AvatarFallback>
          </Avatar>
          <div>
            <h1 className="font-bold text-lg leading-tight tracking-tight">SAHAYAK AI</h1>
            <div className="flex items-center gap-1 text-primary-foreground/80 text-xs font-medium">
              <ShieldCheck className="h-3 w-3" />
              <span>Digital Public Servant</span>
            </div>
          </div>
        </div>
        <div className="flex items-center gap-2">
          <DropdownMenu>
            <DropdownMenuTrigger asChild>
              <Button variant="ghost" size="icon" className="text-primary-foreground hover:bg-primary-foreground/20 rounded-full h-9 w-9">
                <Globe className="h-5 w-5" />
              </Button>
            </DropdownMenuTrigger>
            <DropdownMenuContent align="end" className="w-40 rounded-xl">
              {["English", "हिंदी (Hindi)", "मराठी (Marathi)", "தமிழ் (Tamil)", "తెలుగు (Tamil)"].map((lang) => (
                <DropdownMenuItem 
                  key={lang} 
                  onClick={() => setLanguage(lang)}
                  className={`cursor-pointer rounded-lg ${language === lang ? "bg-primary/10 font-semibold text-primary" : ""}`}
                >
                  {lang}
                </DropdownMenuItem>
              ))}
            </DropdownMenuContent>
          </DropdownMenu>
          <Button variant="ghost" size="icon" className="text-primary-foreground hover:bg-primary-foreground/20 rounded-full h-9 w-9 sm:hidden">
            <Menu className="h-5 w-5" />
          </Button>
        </div>
      </header>

      {/* Trust Banner */}
      <div className="bg-secondary/10 px-4 py-2 flex items-start gap-2 text-xs text-foreground/80 border-b border-border shadow-2xs z-10">
        <Info className="h-4 w-4 text-secondary shrink-0 mt-0.5" />
        <p>Information is verified against official government sources. Your data is secure and private.</p>
      </div>

      {/* Chat Area */}
      <ScrollArea ref={scrollRef} className="flex-1 p-4 bg-muted/30">
        <div className="flex flex-col gap-6 pb-4">
          <AnimatePresence initial={false}>
            {messages.map((msg) => (
              <motion.div
                key={msg.id}
                initial={{ opacity: 0, y: 10, scale: 0.95 }}
                animate={{ opacity: 1, y: 0, scale: 1 }}
                transition={{ duration: 0.3, ease: "easeOut" }}
                className={`flex flex-col ${msg.role === "user" ? "items-end" : "items-start"}`}
              >
                <div className={`flex items-end gap-2 max-w-[85%] ${msg.role === "user" ? "flex-row-reverse" : "flex-row"}`}>
                  {msg.role === "assistant" && (
                    <Avatar className="h-8 w-8 shrink-0 shadow-sm border border-border bg-white mb-1">
                      <AvatarImage src={sahayakAvatar} className="p-1 object-contain" />
                      <AvatarFallback className="text-xs">SA</AvatarFallback>
                    </Avatar>
                  )}
                  
                  <div className={`flex flex-col ${msg.role === "user" ? "items-end" : "items-start"}`}>
                    <div 
                      className={`px-4 py-3 rounded-2xl shadow-sm text-[15px] leading-relaxed ${
                        msg.role === "user" 
                          ? "bg-primary text-primary-foreground rounded-br-sm" 
                          : "bg-card text-card-foreground border border-border rounded-bl-sm"
                      }`}
                      style={{ whiteSpace: "pre-wrap" }}
                    >
                      {msg.content}
                    </div>

                    {/* Scheme Card UI */}
                    {msg.schemeCard && (
                      <motion.div 
                        initial={{ opacity: 0, marginTop: 0 }}
                        animate={{ opacity: 1, marginTop: 8 }}
                        transition={{ delay: 0.2 }}
                        className="bg-card border border-primary/20 rounded-xl p-4 shadow-md w-full max-w-[280px] sm:max-w-xs mt-2 relative overflow-hidden"
                      >
                        <div className="absolute top-0 left-0 w-1 h-full bg-primary" />
                        <h3 className="font-bold text-base text-foreground flex items-center gap-2 mb-2">
                          {msg.schemeCard.title}
                        </h3>
                        <p className="text-sm text-muted-foreground mb-3">{msg.schemeCard.description}</p>
                        <div className="bg-muted rounded-lg p-2.5 text-xs">
                          <span className="font-semibold block mb-1 text-foreground">Eligibility:</span>
                          <span className="text-muted-foreground">{msg.schemeCard.eligibility}</span>
                        </div>
                      </motion.div>
                    )}

                    {msg.role === "assistant" && (
                      <div className="flex items-center gap-2 mt-1 px-1">
                        <span className="text-[10px] text-muted-foreground font-medium">
                          {msg.timestamp.toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' })}
                        </span>
                        <button className="text-muted-foreground hover:text-primary transition-colors">
                          <Volume2 className="h-3 w-3" />
                        </button>
                      </div>
                    )}
                  </div>
                </div>

                {/* Suggestion Chips */}
                {msg.chips && msg.role === "assistant" && (
                  <motion.div 
                    initial={{ opacity: 0 }}
                    animate={{ opacity: 1 }}
                    transition={{ delay: 0.5 }}
                    className="flex flex-wrap gap-2 mt-3 ml-10"
                  >
                    {msg.chips.map((chip, idx) => (
                      <button
                        key={idx}
                        onClick={() => handleChipClick(chip)}
                        className="px-3 py-1.5 bg-background border border-primary/30 text-primary text-sm rounded-full shadow-xs hover:bg-primary hover:text-primary-foreground transition-all flex items-center gap-1 active:scale-95"
                      >
                        {chip}
                        <ChevronRight className="h-3 w-3 opacity-70" />
                      </button>
                    ))}
                  </motion.div>
                )}
              </motion.div>
            ))}
          </AnimatePresence>

          {isTyping && (
            <motion.div 
              initial={{ opacity: 0 }} 
              animate={{ opacity: 1 }} 
              className="flex items-end gap-2 max-w-[80%]"
            >
              <Avatar className="h-8 w-8 shrink-0 shadow-sm border border-border bg-white mb-1">
                <AvatarImage src={sahayakAvatar} className="p-1 object-contain" />
                <AvatarFallback className="text-xs">SA</AvatarFallback>
              </Avatar>
              <div className="bg-card border border-border px-4 py-3 rounded-2xl rounded-bl-sm shadow-sm flex items-center gap-1">
                <div className="w-2 h-2 rounded-full bg-primary/40 animate-bounce" style={{ animationDelay: "0ms" }} />
                <div className="w-2 h-2 rounded-full bg-primary/60 animate-bounce" style={{ animationDelay: "150ms" }} />
                <div className="w-2 h-2 rounded-full bg-primary animate-bounce" style={{ animationDelay: "300ms" }} />
              </div>
            </motion.div>
          )}
        </div>
      </ScrollArea>

      {/* Input Area */}
      <div className="p-3 bg-card border-t border-border shadow-[0_-4px_15px_-5px_rgba(0,0,0,0.05)] z-10">
        <div className="flex items-end gap-2 relative">
          <div className="relative flex-1">
            <Input
              value={inputValue}
              onChange={(e) => setInputValue(e.target.value)}
              onKeyDown={(e) => {
                if (e.key === "Enter" && !e.shiftKey) {
                  e.preventDefault();
                  handleSend();
                }
              }}
              placeholder={`Ask in ${language}...`}
              className="pr-10 py-6 bg-muted/50 border-transparent focus-visible:ring-primary focus-visible:bg-background rounded-2xl shadow-inner text-[15px]"
            />
            {/* Voice Input Button */}
            <Button 
              size="icon" 
              variant="ghost" 
              className={`absolute right-1 top-1.5 rounded-xl h-9 w-9 ${!inputValue ? "text-primary hover:bg-primary/10" : "text-muted-foreground"}`}
              title="Voice Input"
            >
              <Mic className="h-5 w-5" />
            </Button>
          </div>
          
          <Button 
            id="send-btn"
            size="icon" 
            onClick={handleSend}
            disabled={!inputValue.trim()}
            className="h-[52px] w-[52px] rounded-2xl shrink-0 shadow-md transition-all active:scale-95"
          >
            <Send className="h-5 w-5 ml-1" />
          </Button>
        </div>
        <div className="text-center mt-2">
          <span className="text-[10px] text-muted-foreground/70">Powered by SAHAYAK AI • Secure & Private</span>
        </div>
      </div>
    </div>
  );
}